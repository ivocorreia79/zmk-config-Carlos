# zmk-config-Enzo
ZMK firmware for 12x4 ortholinear keyboard Plaid with Enzo keymap
